package com.home.service;

import com.home.model.AggregatorResponse;

public interface AggregatorService {
    AggregatorResponse getLocalTimes(String unitTimeStamp);
}
