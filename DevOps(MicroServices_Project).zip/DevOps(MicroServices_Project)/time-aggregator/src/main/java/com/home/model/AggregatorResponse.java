package com.home.model;

import java.util.ArrayList;
import java.util.List;

public class AggregatorResponse {
    private List<TimeDTO> times = new ArrayList<>();
    private String status;
    private String error;

    public AggregatorResponse(List<TimeDTO> times, String status, String error) {
        this.times = times;
        this.status = status;
        this.error = error;
    }

    public List<TimeDTO> getTimes() {
        return times;
    }

    public void setTimes(List<TimeDTO> times) {
        this.times = times;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }
}
