package com.home.client;

import com.home.model.TimeDTO;
import com.home.model.TimeResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;

@Configuration
public class TimeClient {

    @Autowired
    private RestTemplate restTemplate;

    public TimeDTO callTimeService1(String unixTime) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        HttpEntity<String> entity = new HttpEntity<>(headers);

        return restTemplate.exchange("http://192.168.0.129:8660/api/time/" + unixTime, HttpMethod.GET, entity, TimeDTO.class).getBody();
    }

    public TimeDTO callTimeService2(String unixTime) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        HttpEntity<String> entity = new HttpEntity<>(headers);

        return restTemplate.exchange("http://192.168.0.129:8661/api/time/" + unixTime, HttpMethod.GET, entity, TimeDTO.class).getBody();
    }
}
