package com.home.model;

public class TimeDTO {
    private String timeZoneName;
    private String unixTimeStamp;
    private String localTime;

    public String getTimeZoneName() {
        return timeZoneName;
    }

    public void setTimeZoneName(String timeZoneName) {
        this.timeZoneName = timeZoneName;
    }

    public String getUnixTimeStamp() {
        return unixTimeStamp;
    }

    public void setUnixTimeStamp(String unixTimeStamp) {
        this.unixTimeStamp = unixTimeStamp;
    }

    public String getLocalTime() {
        return localTime;
    }

    public void setLocalTime(String localTime) {
        this.localTime = localTime;
    }
}
