package com.home.model;

public class TimeResponse {
    private String status;
    private TimeDTO result;
    private String error;

    public TimeResponse(String status, TimeDTO result, String error) {
        this.status = status;
        this.result = result;
        this.error = error;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public TimeDTO getResult() {
        return result;
    }

    public void setResult(TimeDTO result) {
        this.result = result;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }
}
