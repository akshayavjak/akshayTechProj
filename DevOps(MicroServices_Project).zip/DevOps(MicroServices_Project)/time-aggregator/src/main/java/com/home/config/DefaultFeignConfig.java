//package com.home.config;
//
//import feign.Request;
//import lombok.NoArgsConstructor;
//import lombok.Setter;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//@Setter
//@NoArgsConstructor
//public class DefaultFeignConfig {
//    private int connectionTimeout = 10000;
//    private int readTimeout = 200000;
//
//    @Bean
//    public Request.Options options() {
//        return new Request.Options(this.connectionTimeout, this.readTimeout);
//    }
//
//}
