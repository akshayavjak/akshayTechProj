package com.home.service.impl;

import com.home.client.TimeClient;
import com.home.model.AggregatorResponse;
import com.home.model.TimeDTO;
import com.home.model.TimeResponse;
import com.home.service.AggregatorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

@Service
public class AggregatorServiceImpl implements AggregatorService {

    private final String reg = "^\\d+$";

    @Autowired
    private TimeClient timeClient;

    @Override
    public AggregatorResponse getLocalTimes(String unixTimeStamp) {
        AggregatorResponse aggregatorResponse;
        if(Pattern.matches(reg, unixTimeStamp)) {
            List<TimeDTO> resultTimes = new ArrayList<>();
            resultTimes.add(timeClient.callTimeService1(unixTimeStamp));
            resultTimes.add(timeClient.callTimeService2(unixTimeStamp));
            aggregatorResponse = new AggregatorResponse(resultTimes, "Success", null);
        } else {
            aggregatorResponse = new AggregatorResponse(null, "Invalid Unix Time Stamp", "Please enter correct 'Unix Time Stamp'");
        }
       return aggregatorResponse;
    }
}
