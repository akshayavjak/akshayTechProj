package com.home.controller;

import com.home.model.AggregatorResponse;
import com.home.service.AggregatorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping
public class AggregatorController {

    @Autowired
    private AggregatorService aggregatorService;

    @GetMapping("/{time}/time")
    public ResponseEntity<AggregatorResponse> getConvertedTime(@PathVariable("time") String unixTimeStamp) {
        return ResponseEntity.accepted().body(aggregatorService.getLocalTimes(unixTimeStamp));
    }
}
